<?php
/**
 * Plugin Name: WP REST API SEO Helper
 * Description: Exposes Rank Math and Yoast SEO meta fields to the WordPress REST API for reading and writing.
 * Version: 1.0.0
 * Author: Antigravity AI
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'wp_rest_seo_helper_register_meta' );

function wp_rest_seo_helper_register_meta() {
    $meta_keys = [
        // Rank Math keys
        'rank_math_title' => 'string',
        'rank_math_description' => 'string',
        'rank_math_focus_keyword' => 'string',
        'rank_math_facebook_title' => 'string',
        'rank_math_facebook_description' => 'string',
        'rank_math_facebook_image' => 'string',
        'rank_math_twitter_title' => 'string',
        'rank_math_twitter_description' => 'string',
        'rank_math_twitter_image' => 'string',

        // Yoast SEO keys
        '_yoast_wpseo_title' => 'string',
        '_yoast_wpseo_metadesc' => 'string',
        '_yoast_wpseo_focuskw' => 'string',
        '_yoast_wpseo_opengraph-title' => 'string',
        '_yoast_wpseo_opengraph-description' => 'string',
        '_yoast_wpseo_opengraph-image' => 'string',
        '_yoast_wpseo_twitter-title' => 'string',
        '_yoast_wpseo_twitter-description' => 'string',
        '_yoast_wpseo_twitter-image' => 'string',
    ];

    foreach ( $meta_keys as $key => $type ) {
        register_meta( 'post', $key, [
            'show_in_rest' => true,
            'single'       => true,
            'type'         => $type,
            'auth_callback' => function() {
                return current_user_can( 'edit_posts' );
            }
        ]);
        
        register_meta( 'page', $key, [
            'show_in_rest' => true,
            'single'       => true,
            'type'         => $type,
            'auth_callback' => function() {
                return current_user_can( 'edit_posts' );
            }
        ]);
    }
}
